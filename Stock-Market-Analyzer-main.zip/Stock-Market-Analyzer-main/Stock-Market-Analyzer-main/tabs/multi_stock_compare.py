import streamlit as st
import yfinance as yf
import pandas as pd


def multi_stock_tab():

    st.header("📊 Multi-Stock Comparison")

    # Select multiple stocks
    stocks = st.multiselect(
        "Select Stocks to Compare",
        ["AAPL","MSFT","GOOGL","AMZN","TSLA","NVDA","META","NFLX","AMD","INTC"],
        default=["AAPL","MSFT"]
    )

    compare_period = st.selectbox(
        "Select Period",
        ["6mo","1y","2y","5y"]
    )

    if st.button("Compare Stocks"):

        if len(stocks) < 2:
            st.warning("Please select at least 2 stocks to compare.")
            return

        try:
            data = yf.download(stocks, period=compare_period, progress=False)

            if data.empty:
                st.error("❌ Could not download stock data.")
                return

            # Extract close prices
            if isinstance(data.columns, pd.MultiIndex):
                close = data["Close"]
            else:
                close = data[["Close"]]

            close = close.dropna()

            # Price comparison chart
            st.subheader("📈 Price Comparison")
            st.line_chart(close)

            # Normalized growth comparison
            normalized = close / close.iloc[0] * 100

            st.subheader("📊 Growth Comparison (Start = 100)")
            st.line_chart(normalized)

            # Performance metrics
            returns = (close.iloc[-1] / close.iloc[0] - 1) * 100
            volatility = close.pct_change().std()

            metrics = pd.DataFrame({
                "Stock": returns.index,
                "Total Return %": returns.values,
                "Volatility": volatility.values
            })

            st.subheader("📊 Performance Metrics")
            st.dataframe(metrics, use_container_width=True)

            # Best performing stock
            best_stock = returns.idxmax()
            st.success(f"🏆 Best Performing Stock: {best_stock}")

        except Exception as e:
            st.error("⚠️ Error comparing stocks")
            st.text(str(e))