import streamlit as st
import speech_recognition as sr
import pyttsx3
import requests


# Hugging Face API
API_URL = "https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.2"

headers = {
    "Authorization": f"Bearer {st.secrets['HF_TOKEN']}"
}


def ai_assistant_tab():

    st.header("🤖 AI Stock Assistant (Text + Voice)")

    if "messages" not in st.session_state:
        st.session_state.messages = []

    # Show chat history
    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.write(msg["content"])

    col1, col2 = st.columns([3,1])

    # Text input
    user_input = col1.chat_input("Ask anything about stock market...")

    # Voice button
    if col2.button("🎤 Speak"):
        user_input = recognize_voice()

    if user_input:

        st.session_state.messages.append({"role":"user","content":user_input})

        with st.chat_message("user"):
            st.write(user_input)

        response = generate_response(user_input)

        st.session_state.messages.append({"role":"assistant","content":response})

        with st.chat_message("assistant"):
            st.write(response)

        speak(response)


# Voice recognition
def recognize_voice():

    r = sr.Recognizer()

    with sr.Microphone() as source:
        st.info("Listening... Speak now")
        audio = r.listen(source)

    try:
        text = r.recognize_google(audio)
        return text
    except:
        return "Sorry, I could not understand your voice."


# Text to speech
def speak(text):

    engine = pyttsx3.init()
    engine.say(text)
    engine.runAndWait()


# AI response from HuggingFace
def generate_response(question):

    payload = {
        "inputs": question
    }

    try:

        response = requests.post(API_URL, headers=headers, json=payload)

        result = response.json()

        if isinstance(result, list):
            return result[0]["generated_text"]

        else:
            return "AI is loading the model. Please try again in a few seconds."

    except Exception as e:
        return f"AI Error: {e}"